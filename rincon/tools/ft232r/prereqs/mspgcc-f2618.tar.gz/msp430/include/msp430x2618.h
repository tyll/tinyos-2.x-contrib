#if !defined(__msp430x2618)
#define __msp430x2618

/* msp430x2618.h
 *
 * mspgcc project: MSP430 device headers
 * MSP430x2618 '2618 header (64 or 80 pins)
 *
 * mhh rrc 10/11/07
 *
 * Switches:
 *   __MSP430_HAS_80_PINS__
 *
 */

#include <iomacros.h>

#define __MSP430_HAS_WDT__
#define __MSP430_HAS_MPY__
#define __MSP430_HAS_PORT1_R__
#define __MSP430_HAS_PORT2_R__
#define __MSP430_HAS_PORT3_R__
#define __MSP430_HAS_PORT4_R__
#define __MSP430_HAS_PORT5_R__
#define __MSP430_HAS_PORT6_R__
#ifdef __MSP430_HAS_80_PINS
#define __MSP430_HAS_PORT7_R__
#define __MSP430_HAS_PORT8_R__
#define __MSP430_HAS_PORTA_R__
#endif
#define __MSP430_HAS_USCI__
#define __MSP430_HAS_USCI1__
#define __MSP430_HAS_TA3__
#define __MSP430_HAS_TB7__
#define __MSP430_HAS_BASIC_CLOCK__
#define __MSP430_HAS_BC2__
#define __MSP430_HAS_FLASH__
#define __MSP430_HAS_COMPA__
#define __MSP430_HAS_SVS__
#define __MSP430_HAS_ADC12__
#define __MSP430_HAS_DAC12__
#define __MSP430_HAS_DMA_3__

#define __msp430_has_svs_at_0x55

#include <msp430/mpy.h>
#include <msp430/gpio.h>
#include <msp430/svs.h>
#include <msp430/flash.h>
#include <msp430/compa.h>
#include <msp430/timera.h>
#include <msp430/timerb.h>
#include <msp430/basic_clock.h>
#include <msp430/usci.h>
#include <msp430/adc12.h>
#include <msp430/dac12.h>
#include <msp430/dma2618.h>

/* Flash controller extras: */
#define FCTL4_              0x01BE  /* FLASH Control 4 */
sfrw (FCTL4,FCTL4_);
#define MRG0                (1<<4)
#define MRG1                (1<<5)

#include <msp430/common.h>

/* F2618 *does* have DCOR, despite what basic_clock.h says */
#define DCOR 0x1

#define IE1_                0x0000  /* Interrupt Enable 1 */
sfrb(IE1,IE1_);
#define WDTIE               (1<<0)
#define OFIE                (1<<1)
#define NMIIE               (1<<4)
#define ACCVIE              (1<<5)

#define IFG1_               0x0002  /* Interrupt Flag 1 */
sfrb(IFG1,IFG1_);
#define WDTIFG              (1<<0)
#define OFIFG               (1<<1)
#define PORIFG              (1<<2)
#define RSTIFG              (1<<3)
#define NMIIFG              (1<<4)

#define IE2_                0x0001  /* Interrupt Enable 2 */
sfrb(IE2,IE2_);
#define UCA0RXIE            (1<<0)
#define UCA0TXIE            (1<<1)
#define UCB0RXIE            (1<<2)
#define UCB0TXIE            (1<<3)

#define IFG2_               0x0003  /* Interrupt Flag 2 */
sfrb(IFG2,IFG2_);
#define UCA0RXIFG           (1<<0)
#define UCA0TXIFG           (1<<1)
#define UCB0RXIFG           (1<<2)
#define UCB0TXIFG           (1<<3)

/*** For USCI1 */
#define UCA1RXIE            (1<<0)
#define UCA1TXIE            (1<<1)
#define UCB1RXIE            (1<<2)
#define UCB1TXIE            (1<<3)

#define UCA1RXIFG           (1<<0)
#define UCA1TXIFG           (1<<1)
#define UCB1RXIFG           (1<<2)
#define UCB1TXIFG           (1<<3)

/*
 * mhh 10/11/07 f2618 doesn't have these
 *
#define ME1_                0x0004  /* Module Enable 1 * /
sfrb(ME1,ME1_);

#define ME2_                0x0005  /* Module Enable 2 * /
sfrb(ME2,ME2_);
#define USPIE1              (1<<4)
#define URXE1               (1<<4)
#define UTXE1               (1<<5)
 */

#define DAC12_VECTOR        28      /* 0xFFDC DAC 12 */
#define DMA_VECTOR          30      /* 0xFFDE DMA */
#define USCI1TX_VECTOR      32      /* 0xFFE0 USCI A1/B1 TX */
#define USCI1RX_VECTOR      34      /* 0xFFE2 USCI A1/B1 RX */
#define PORT1_VECTOR        36      /* 0xFFE4 Port 1 */
#define PORT2_VECTOR        38      /* 0xFFE6 Port 2 */
#define UNKNOWN_VECTOR      40      /* 0xFFE8 ??? */
#define ADC12_VECTOR        42      /* 0xFFEA ADC */
#define USCI0TX_VECTOR      44      /* 0xFFEC USCI A0/B0 TX */
#define USCI0RX_VECTOR      46      /* 0xFFEE USCI A0/B0 RX */
#define TIMER0_A1_VECTOR    48      /* 0xFFF0 Timer A CC1-2, TA */
#define TIMER0_A0_VECTOR    50      /* 0xFFF2 Timer A CC0 */
#define WDT_VECTOR          52      /* 0xFFF4 Watchdog Timer */
#define COMPARATORA_VECTOR  54      /* 0xFFF6 Comparator A */
#define TIMER0_B1_VECTOR    56      /* 0xFFF8 Timer B CC1-6, TB */
#define TIMER0_B0_VECTOR    58      /* 0xFFFA Timer B CC0 */
#define NMI_VECTOR          60      /* 0xFFFC Non-maskable */

#define TIMERA1_VECTOR      TIMER0_A1_VECTOR
#define TIMERA0_VECTOR      TIMER0_A0_VECTOR
#define TIMERB1_VECTOR      TIMER0_B1_VECTOR
#define TIMERB0_VECTOR      TIMER0_B0_VECTOR

#define ADC_VECTOR          ADC12_VECTOR
#define DAC_VECTOR          DAC12_VECTOR

#endif /* #ifndef __msp430x2618 */

